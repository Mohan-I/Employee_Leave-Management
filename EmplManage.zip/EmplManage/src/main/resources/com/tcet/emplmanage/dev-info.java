 /* 

    Project Co-ordinator  : Mr. Amitanand Mishra
    # Advance Java Expert - Faculty Member of MCA 

    / ======= \
   / __________\
  | ___________ |
  | | -       | |
  | |         | |        TEAM LEADER 
  | |_________| |_______________________________
  \=____________/   created by mohan yadav      )
  / """"""""""" \         & team               /
 / ::::::::::::: \                         =D-'                                                             
(_________________)                                                                                                 
                                                                                                                     
# Worked on Frontend & Backend and made ensure that the project is good enough applying real - world knowledge       
/////////////////////////////////////////////////////////////////////
    |
My Beloved Teammates:
    |
# Member : 01
# Name : Anuj Yadav
# Worked on : The guy who worked on database.java - Managed DB connections.
    |
# Member : 02
# Name : Sagar Tayde
# Worked on : Managed leave-approval workflow and even made bar chart in DashboardController.java - Generating various reports
    |
# Member : 03
# Name : Suraj Yadav
# Worked on : Worked on Frontend Graphical User Interface with logical approach.

*/