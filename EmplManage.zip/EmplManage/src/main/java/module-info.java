module com.tcet.emplmanage {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.base;

    opens com.tcet.emplmanage to javafx.fxml;
    exports com.tcet.emplmanage;
}
