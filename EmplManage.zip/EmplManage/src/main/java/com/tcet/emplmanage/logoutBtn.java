/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tcet.emplmanage;

/**
 *  FOR FUTURE UPDATES IF IN CASE REQUIRED AS PER REAL WORLD PROJECT
 *  SO WE CAN REDIRECT ADMINS, EMPLOYEES OR HRs TO RETURN TO A CONSTANT PATH ("primary.fxml")
 *  OR EXIT THE SYSTEM BY A CERTAIN AD.
 * ------ @author mohan
 */
class logoutBtn {
    
}
