package com.tcet.emplmanage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class PrimaryController {

    @FXML
    private Label close;
    
    @FXML
    private Button loginBtn;

    @FXML
    private AnchorPane main_form;
    
    @FXML
    private PasswordField password;

    @FXML
    private TextField username;

    @FXML
    private Button primaryButton; 
    
    // Database Tools
    private Connection connect;
    private PreparedStatement prepare;
    private ResultSet result;
    
    private double x = 0;
    private double y = 0;
    
    /**
     * Handles the login logic for the Admin user.
     * This logic performs database authentication against the 'admin' table.
     */
    public void loginAdmin(){
        String sql = "SELECT * FROM admin WHERE username = ? and password = ?";
        
        try{
            connect = database.connectDb(); // Assuming 'database.connectDb()' exists
            
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, username.getText());            
            prepare.setString(2, password.getText());

            result = prepare.executeQuery();
            Alert alert;
            
            if(username.getText().isEmpty() || password.getText().isEmpty()){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all the Blank Fields !");
                alert.showAndWait();
            }else{
                if(result.next()){
                    getData.username = username.getText(); 
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Login Successfull !");
                    alert.showAndWait();
                    
                    loginBtn.getScene().getWindow().hide();
                    Parent root = FXMLLoader.load(getClass().getResource("dashboard.fxml")); // Loads Admin Dashboard
                    
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    
                    // Logic to make the window draggable 
                    root.setOnMousePressed((MouseEvent event) ->{
                        x = event.getSceneX();
                        y = event.getSceneY();
                    });
                    
                    root.setOnMouseDragged((MouseEvent event)-> {
                        stage.setX(event.getScreenX() - x);
                        stage.setY(event.getScreenY() - y);
                    });
                    
                    stage.initStyle(StageStyle.TRANSPARENT);
                    stage.setScene(scene);
                    stage.show();
    
                }else{
                    alert = new Alert(AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Incorrect Username/Password !");
                    alert.showAndWait();
                }
            }
            
        } catch(SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Database Error");
            alert.setHeaderText(null);
            alert.setContentText("Unable to connect to database: " + e.getMessage());
            alert.showAndWait();
        } catch(Exception e){
            e.printStackTrace();
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("An unexpected error occurred!");
            alert.showAndWait();
        } finally {
            // Close resources in finally block
            try {
                if (result != null) result.close();
                if (prepare != null) prepare.close();
                if (connect != null) connect.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public void loginEmployee(){
    try {
        // Hide current window
        if (primaryButton != null) {
            primaryButton.getScene().getWindow().hide();
        } else if (loginBtn != null) {
            loginBtn.getScene().getWindow().hide();
        }
       
        // Load employee login form
        Parent root = FXMLLoader.load(getClass().getResource("emp_log.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        // Draggable window logic
        root.setOnMousePressed((MouseEvent event) ->{
            x = event.getSceneX();
            y = event.getSceneY();
        });
        
        root.setOnMouseDragged((MouseEvent event)-> {
            stage.setX(event.getScreenX() - x);
            stage.setY(event.getScreenY() - y);
        });
        
        stage.initStyle(StageStyle.TRANSPARENT);
        stage.setScene(scene);
        stage.show();

    } catch(IOException e) {
        e.printStackTrace();
        // Use direct Alert instead of showError method
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Navigation Error");
        alert.setHeaderText(null);
        alert.setContentText("Failed to load employee login form: " + e.getMessage());
        alert.showAndWait();
    } catch(Exception e){
        e.printStackTrace();
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("An unexpected error occurred during scene switch!");
        alert.showAndWait();
    }
}
    /**
     * Initializes the controller after its root element has been completely processed.
     */
    @FXML
    public void initialize() {
        // Add Dragging Logic to the main form container
        main_form.setOnMousePressed((MouseEvent event) -> {
            x = event.getSceneX();
            y = event.getSceneY();
        });

        // When mouse is dragged, update the window position
        main_form.setOnMouseDragged((MouseEvent event) -> {
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setX(event.getScreenX() - x);
            stage.setY(event.getScreenY() - y);
            stage.setOpacity(.8);
        });

        // When mouse is released, reset opacity
        main_form.setOnMouseReleased((MouseEvent event) -> {
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setOpacity(1);
        });

        // Add Close Button/Icon Handler
        if (close != null) {
            close.setOnMouseClicked((MouseEvent event) -> {
                close();
            });
        }
    }
    
    // --- Action Methods ---

    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
    
    /**
     * Handles the application close function.
     */
    public void close(){
        System.exit(0);
    }
//     
//   For Error handling during development :
//
//    private void showError(String navigation_Error, String string) {
//        throw new UnsupportedOperationException("Not supported yet."); 
//        Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
}