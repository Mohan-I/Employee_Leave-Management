/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tcet.emplmanage;

/**
 *
 * @author mohan
 */
public class getData {
    public static String username;
    public static String path;
    public static String employeeId;  
    public static String fullName;     
    public static String position;   
    public static String status;      
}