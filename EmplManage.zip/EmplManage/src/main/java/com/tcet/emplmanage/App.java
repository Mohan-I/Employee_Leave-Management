package com.tcet.emplmanage;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) {
        try {
            scene = new Scene(loadFXML("primary"), 640, 480);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            System.err.println("Error starting application: " + e.getMessage());
            e.printStackTrace();
            // Show an error alert if possible
            showErrorAlert("Failed to start application: " + e.getMessage());
        }
    }

    static void setRoot(String fxml) throws IOException {
        try {
            scene.setRoot(loadFXML(fxml));
        } catch (IOException e) {
            System.err.println("Error loading FXML: " + fxml);
            e.printStackTrace();
            throw e;
        }
    }

    private static Parent loadFXML(String fxml) throws IOException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
            return fxmlLoader.load();
        } catch (IOException e) {
            System.err.println("Failed to load FXML file: " + fxml + ".fxml");
            System.err.println("Resource path: " + App.class.getResource(fxml + ".fxml"));
            throw e;
        }
    }

    private void showErrorAlert(String message) {
        // Try to show a JavaFX alert, or fall back to console
        try {
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.ERROR
            );
            alert.setTitle("Application Error");
            alert.setHeaderText("Failed to Start");
            alert.setContentText(message);
            alert.showAndWait();
        } catch (Exception ex) {
            // If JavaFX alert fails, just print to console
            System.err.println(message);
        }
    }

    public static void main(String[] args) {
        try {
            System.out.println("Starting JavaFX application...");
            launch();
        } catch (Exception e) {
            System.err.println("Fatal error in main: " + e.getMessage());
            e.printStackTrace();
        }
    }
}