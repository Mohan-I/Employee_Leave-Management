package com.tcet.emplmanage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class EmployeeLoginController {

    @FXML
    private Button loginBtn;

    @FXML
    private StackPane main_form;
    
    @FXML
    private PasswordField password;

    @FXML
    private TextField username;
    
    @FXML
    private Button close_Btn;
       
    @FXML
    private Button logoutBtn;
    
    private double x = 0;
    private double y = 0;
    
    @FXML
    public void initialize() {
        // Add enter key support for both fields
        username.setOnAction(e -> handleLogin());
        password.setOnAction(e -> handleLogin());
        
        // Add draggable window logic
        main_form.setOnMousePressed((MouseEvent event) -> {
            x = event.getSceneX();
            y = event.getSceneY();
        });

        main_form.setOnMouseDragged((MouseEvent event) -> {
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setX(event.getScreenX() - x);
            stage.setY(event.getScreenY() - y);
        });
    }
    
    @FXML
    private void handleLogin() {
        // First check if credentials are correct, then check status
        String sql = "SELECT * FROM employee WHERE emp_ID = ? AND password = ?";
        
        Connection connect = null;
        PreparedStatement prepare = null;
        ResultSet result = null;
        
        try {
            connect = database.connectDb();
            if (connect == null) {
                showError("Database Error", "Unable to connect to database");
                return;
            }
            
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, username.getText());            
            prepare.setString(2, password.getText());

            result = prepare.executeQuery();
            Alert alert;
            
            if(username.getText().isEmpty() || password.getText().isEmpty()){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all the blank fields!");
                alert.showAndWait();
            } else {
                if(result.next()){
                    // Check if employee status allows login
                    String status = result.getString("status");
                    
                    // Define which statuses are allowed to login
                    if ("Active".equals(status) || "Leave-Approved".equals(status) || "Pending".equals(status)) {
                        // Store employee data
                        getData.employeeId = result.getString("emp_ID");
                        getData.username = username.getText();
                        getData.fullName = result.getString("fullname");
                        getData.position = result.getString("position");
                        getData.status = status;
                        
                        alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Information Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Employee Login Successful!\nWelcome, " + getData.fullName + "\nStatus: " + status);
                        alert.showAndWait();
                        
                        loadSecondaryDashboard();
                    } else {
                        alert = new Alert(AlertType.WARNING);
                        alert.setTitle("Access Denied");
                        alert.setHeaderText(null);
                        alert.setContentText("Your account status is: " + status + "\nThis status does not allow login.\nPlease contact administrator.");
                        alert.showAndWait();
                    }
   
                } else {
                    alert = new Alert(AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Incorrect Employee ID or Password!\n\nTry:\nEmployee ID: 2007\nPassword: MICkpF9q");
                    alert.showAndWait();
                }
            }
            
        } catch(SQLException e) {
            e.printStackTrace();
            showError("Database Error", "Unable to connect to database: " + e.getMessage());
        } catch(Exception e){
            e.printStackTrace();
            showError("Error", "An unexpected error occurred: " + e.getMessage());
        } finally {
            // Close resources
            try {
                if (result != null) result.close();
                if (prepare != null) prepare.close();
                if (connect != null) connect.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    private void loadSecondaryDashboard() {
    try {
        // Hide current login window
        Stage currentStage = (Stage) loginBtn.getScene().getWindow();
        currentStage.hide();
        
        // FIXED PATH - Use simple relative path
        Parent root = FXMLLoader.load(getClass().getResource("secondary.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        
        // Make the new window draggable
        root.setOnMousePressed((MouseEvent event) ->{
            x = event.getSceneX();
            y = event.getSceneY();
        });
        
        root.setOnMouseDragged((MouseEvent event)-> {
            stage.setX(event.getScreenX() - x);
            stage.setY(event.getScreenY() - y);
        });
        
        stage.initStyle(StageStyle.TRANSPARENT);
        stage.setScene(scene);
        stage.show();
        
    } catch (IOException e) {
        e.printStackTrace();
        showError("Navigation Error", "Cannot load employee dashboard. Make sure 'secondary.fxml' exists.\nError: " + e.getMessage());
        
        // Reopen login window if navigation fails
        try {
            Stage currentStage = (Stage) loginBtn.getScene().getWindow();
            currentStage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}    
    private void showError(String title, String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    @FXML
    private void close() {
        System.exit(0);
    }
    
    @FXML
    private void logout() {
        // Close current window and reopen login
        Stage stage = (Stage) logoutBtn.getScene().getWindow();
        stage.close();
        
        } 
}