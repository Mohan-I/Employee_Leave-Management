package com.tcet.emplmanage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SecondaryController implements Initializable {

    @FXML
    private Button closeBtn;

    @FXML
    private Button minimizeBtn;

    @FXML
    private ImageView employeeImage;

    @FXML
    private Button logoutBtn;

    @FXML
    private Text employeeIdText;

    @FXML
    private Button homeBtn;

    @FXML
    private Button settingsBtn;

    @FXML
    private Label employeeNameText;

    @FXML
    private Label employeePositionText;

    @FXML
    private CheckBox agreeCheckbox;

    @FXML
    private Button submitLeaveBtn;

    @FXML
    private Label nameLabel;

    @FXML
    private Label positionLabel;

    @FXML
    private DatePicker leaveFromDate;

    @FXML
    private DatePicker leaveToDate;

    @FXML
    private TextArea remarkTextArea;

    @FXML
    private Label daysCountLabel;

    @FXML
    private TableView<LeaveData> leaveTableView;

    @FXML
    private TableColumn<LeaveData, String> leaveFromColumn;

    @FXML
    private TableColumn<LeaveData, String> leaveToColumn;

    @FXML
    private TableColumn<LeaveData, String> statusColumn;

    @FXML
    private AnchorPane home_field;

    @FXML
    private AnchorPane settings_field;

    // Settings section fields
    @FXML
    private TextField currentPasswordField;

    @FXML
    private TextField newPasswordField;

    @FXML
    private TextField confirmPasswordField;

    @FXML
    private Button changePasswordBtn;

    @FXML
    private Label settingsNameLabel;

    @FXML
    private Label settingsPositionLabel;

    private Connection connect;
    private PreparedStatement prepare;
    private ResultSet result;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("SecondaryController initialized");
        
        // Set employee data from getData class
        loadEmployeeData();
        
        // Initialize leave history table
        initializeLeaveTable();
        
        // Load leave history
        loadLeaveHistory();
        
        // Setup date change listeners for leave calculation
        setupDateListeners();
        
        // Set initial days count
        daysCountLabel.setText("0");
        
        // Set initial tab (Home)
        showHomeSection();
    }

    private void loadEmployeeData() {
        try {
            System.out.println("Loading employee data for: " + getData.employeeId);
            
            // Set basic employee info
            if (getData.fullName != null) {
                if (employeeNameText != null) employeeNameText.setText(getData.fullName);
                if (nameLabel != null) nameLabel.setText(getData.fullName);
                if (settingsNameLabel != null) settingsNameLabel.setText(getData.fullName);
            }
            
            if (getData.position != null) {
                if (employeePositionText != null) employeePositionText.setText(getData.position);
                if (positionLabel != null) positionLabel.setText(getData.position);
                if (settingsPositionLabel != null) settingsPositionLabel.setText(getData.position);
            }
            
            if (getData.employeeId != null && employeeIdText != null) {
                employeeIdText.setText(getData.employeeId);
            }

            // Load employee image from database
            loadEmployeeImage();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load employee data: " + e.getMessage());
        }
    }

    private void loadEmployeeImage() {
        String sql = "SELECT image FROM employee WHERE emp_ID = ?";
        
        try {
            connect = database.connectDb();
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, getData.employeeId);
            result = prepare.executeQuery();

            if (result.next()) {
                String imagePath = result.getString("image");
                if (imagePath != null && !imagePath.isEmpty()) {
                    try {
                        Image image = new Image("file:" + imagePath, 150, 150, true, true);
                        employeeImage.setImage(image);
                    } catch (Exception e) {
                        System.out.println("Could not load employee image: " + e.getMessage());
                        setDefaultImage();
                    }
                } else {
                    setDefaultImage();
                }
            } else {
                setDefaultImage();
            }
        } catch (Exception e) {
            e.printStackTrace();
            setDefaultImage();
        } finally {
            closeResources();
        }
    }

    private void setDefaultImage() {
        try {
            employeeImage.setImage(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initializeLeaveTable() {
        if (leaveFromColumn != null) {
            leaveFromColumn.setCellValueFactory(new PropertyValueFactory<>("leaveFrom"));
        }
        if (leaveToColumn != null) {
            leaveToColumn.setCellValueFactory(new PropertyValueFactory<>("leaveTo"));
        }
        if (statusColumn != null) {
            statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        }
    }

    private void loadLeaveHistory() {
        String sql = "SELECT leave_from, leave_to, status, remarks FROM employee WHERE emp_ID = ? AND leave_from IS NOT NULL ORDER BY leave_from DESC";
        
        ObservableList<LeaveData> leaveList = FXCollections.observableArrayList();
        
        try {
            connect = database.connectDb();
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, getData.employeeId);
            result = prepare.executeQuery();

            while (result.next()) {
                java.sql.Date leaveFromDate = result.getDate("leave_from");
                java.sql.Date leaveToDate = result.getDate("leave_to");
                
                String leaveFrom = (leaveFromDate != null) ? leaveFromDate.toString() : "N/A";
                String leaveTo = (leaveToDate != null) ? leaveToDate.toString() : "N/A";
                String status = result.getString("status");
                String remarks = result.getString("remarks");

                LeaveData leaveData = new LeaveData(leaveFrom, leaveTo, status, remarks);
                leaveList.add(leaveData);
            }

            if (leaveTableView != null) {
                leaveTableView.setItems(leaveList);
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to load leave history: " + e.getMessage());
        } finally {
            closeResources();
        }
    }

    private void setupDateListeners() {
        if (leaveFromDate != null) {
            leaveFromDate.valueProperty().addListener((observable, oldValue, newValue) -> calculateLeaveDays());
        }
        if (leaveToDate != null) {
            leaveToDate.valueProperty().addListener((observable, oldValue, newValue) -> calculateLeaveDays());
        }
    }

    private void calculateLeaveDays() {
        if (leaveFromDate != null && leaveToDate != null && 
            leaveFromDate.getValue() != null && leaveToDate.getValue() != null) {
            
            LocalDate fromDate = leaveFromDate.getValue();
            LocalDate toDate = leaveToDate.getValue();

            if (!fromDate.isAfter(toDate)) {
                long daysBetween = ChronoUnit.DAYS.between(fromDate, toDate) + 1;
                if (daysCountLabel != null) {
                    daysCountLabel.setText(String.valueOf(daysBetween));
                }
            } else {
                if (daysCountLabel != null) {
                    daysCountLabel.setText("0");
                }
                showAlert("Date Error", "Leave From date cannot be after Leave To date");
            }
        } else {
            if (daysCountLabel != null) {
                daysCountLabel.setText("0");
            }
        }
    }

    @FXML
    private void submitLeaveApplication() {
        try {
            // Validate inputs
            if (leaveFromDate.getValue() == null || leaveToDate.getValue() == null) {
                showAlert("Error", "Please select both Leave From and Leave To dates");
                return;
            }

            if (remarkTextArea.getText().isEmpty()) {
                showAlert("Error", "Please provide remarks for your leave application");
                return;
            }

            if (!agreeCheckbox.isSelected()) {
                showAlert("Error", "Please agree to the terms and conditions");
                return;
            }

            // Check if dates are valid
            LocalDate fromDate = leaveFromDate.getValue();
            LocalDate toDate = leaveToDate.getValue();
            
            if (fromDate.isAfter(toDate)) {
                showAlert("Date Error", "Leave From date cannot be after Leave To date");
                return;
            }

            // Update employee record with new leave application
            String sql = "UPDATE employee SET leave_from = ?, leave_to = ?, remarks = ?, status = 'Pending' WHERE emp_ID = ?";
            
            connect = database.connectDb();
            prepare = connect.prepareStatement(sql);
            
            // Convert LocalDate to java.sql.Date
            java.sql.Date sqlFromDate = java.sql.Date.valueOf(fromDate);
            java.sql.Date sqlToDate = java.sql.Date.valueOf(toDate);
            
            prepare.setDate(1, sqlFromDate);
            prepare.setDate(2, sqlToDate);
            prepare.setString(3, remarkTextArea.getText());
            prepare.setString(4, getData.employeeId);

            int affectedRows = prepare.executeUpdate();

            if (affectedRows > 0) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Success");
                alert.setHeaderText(null);
                alert.setContentText("Leave application submitted successfully!\nStatus: Pending Approval");
                alert.showAndWait();

                // Refresh leave history
                loadLeaveHistory();
                
                // Clear form
                clearLeaveForm();
                
                // Update getData status
                getData.status = "Pending";
                
            } else {
                showAlert("Error", "Failed to submit leave application");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to submit leave application: " + e.getMessage());
        } finally {
            closeResources();
        }
    }

    private void clearLeaveForm() {
        if (leaveFromDate != null) leaveFromDate.setValue(null);
        if (leaveToDate != null) leaveToDate.setValue(null);
        if (remarkTextArea != null) remarkTextArea.clear();
        if (daysCountLabel != null) daysCountLabel.setText("0");
        if (agreeCheckbox != null) agreeCheckbox.setSelected(false);
    }

    @FXML
    private void homeBtnAction() {
        showHomeSection();
    }

    @FXML
    private void settingsBtnAction() {
        showSettingsSection();
    }

    private void showHomeSection() {
        System.out.println("Showing Home Section");
        if (home_field != null) {
            home_field.setVisible(true);
        }
        if (settings_field != null) {
            settings_field.setVisible(false);
        }
        
        // Update button styles to show active state
        updateButtonStyles(true);
    }

    private void showSettingsSection() {
        System.out.println("Showing Settings Section");
        if (home_field != null) {
            home_field.setVisible(false);
        }
        if (settings_field != null) {
            settings_field.setVisible(true);
        }
        
        // Update button styles to show active state
        updateButtonStyles(false);
    }

    private void updateButtonStyles(boolean isHomeActive) {
        if (homeBtn != null) {
            if (isHomeActive) {
                homeBtn.setStyle("-fx-background-color: #FF0075; -fx-text-fill: white;");
                settingsBtn.setStyle("-fx-background-color: #8F43EE; -fx-text-fill: white;");
            } else {
                homeBtn.setStyle("-fx-background-color: #8F43EE; -fx-text-fill: white;");
                settingsBtn.setStyle("-fx-background-color: #FF0075; -fx-text-fill: white;");
            }
        }
    }

    @FXML
    private void changePassword() {
        try {
            String currentPassword = currentPasswordField.getText();
            String newPassword = newPasswordField.getText();
            String confirmPassword = confirmPasswordField.getText();

            // Validate inputs
            if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                showAlert("Error", "Please fill in all password fields");
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                showAlert("Error", "New password and confirm password do not match");
                return;
            }

            if (newPassword.length() < 6) {
                showAlert("Error", "New password must be at least 6 characters long");
                return;
            }

            // Verify current password
            String verifySql = "SELECT password FROM employee WHERE emp_ID = ?";
            connect = database.connectDb();
            prepare = connect.prepareStatement(verifySql);
            prepare.setString(1, getData.employeeId);
            result = prepare.executeQuery();

            if (result.next()) {
                String storedPassword = result.getString("password");
                
                if (!storedPassword.equals(currentPassword)) {
                    showAlert("Error", "Current password is incorrect");
                    return;
                }

                // Update password
                String updateSql = "UPDATE employee SET password = ? WHERE emp_ID = ?";
                prepare = connect.prepareStatement(updateSql);
                prepare.setString(1, newPassword);
                prepare.setString(2, getData.employeeId);

                int affectedRows = prepare.executeUpdate();

                if (affectedRows > 0) {
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Password changed successfully!");
                    alert.showAndWait();

                    // Clear password fields
                    currentPasswordField.clear();
                    newPasswordField.clear();
                    confirmPasswordField.clear();

                } else {
                    showAlert("Error", "Failed to change password");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to change password: " + e.getMessage());
        } finally {
            closeResources();
        }
    }

    @FXML
    private void close() {
        System.exit(0);
    }

    @FXML
    private void minimize() {
        if (minimizeBtn != null && minimizeBtn.getScene() != null) {
            Stage stage = (Stage) minimizeBtn.getScene().getWindow();
            stage.setIconified(true);
        }
    }

    @FXML
    private void logout() {
        try {
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Logout");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to logout?");

            if (alert.showAndWait().get() == javafx.scene.control.ButtonType.OK) {
                // Close current window
                Stage stage = (Stage) logoutBtn.getScene().getWindow();
                stage.close();

                // You can add code here to reopen login window if needed
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Logout Error", "Failed to logout: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    private void showInfo(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void closeResources() {
        try {
            if (result != null) result.close();
            if (prepare != null) prepare.close();
            if (connect != null) connect.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Inner class for leave data table
    public static class LeaveData {
        private final String leaveFrom;
        private final String leaveTo;
        private final String status;
        private final String remarks;

        public LeaveData(String leaveFrom, String leaveTo, String status, String remarks) {
            this.leaveFrom = leaveFrom;
            this.leaveTo = leaveTo;
            this.status = status;
            this.remarks = remarks;
        }

        public String getLeaveFrom() {
            return leaveFrom;
        }

        public String getLeaveTo() {
            return leaveTo;
        }

        public String getStatus() {
            return status;
        }

        public String getRemarks() {
            return remarks;
        }
    }
}