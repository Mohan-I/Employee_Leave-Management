/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tcet.emplmanage;

/**
 *
 * @author mohan
 */

/*
   ,=""=,
  c , _,{
  /\  @ )                 __
 /  ^~~^\          <=.,__/ '}=
(_/ ,, ,,)          \_ _>_/~
 ~\_(/-\)'-,_,_,_,-'(_)-(_)  - Thanks for looking on my code.
     
*/
import java.sql.Date; 

public class employeeData {
    // Database Fields (excluding 'id' if it's purely for the DB)
    // NOTE: 'id' (Primary Key) is often included in the model, so it's added here.
    private Integer id;
    private String emp_ID;
    private String fullname;
    private String position;
    private Date leave_from; // Mapped to date
    private Date leave_to;   // Mapped to date
    private String remarks;  // Mapped to text
    private String status;   // Mapped to enum (String in Java)
    private String password; // Mapped to varchar(225)
    private String image;    // Mapped to varchar(225)

    // --- CONSTRUCTOR ---
    // A constructor with all fields is the most versatile option.
    // NOTE: 'leave_to' and 'password' were missing in your original.
    public employeeData(Integer id, String emp_ID, String fullname, String position, Date leave_from, Date leave_to, String remarks, String status, String password, String image) {
        this.id = id;
        this.emp_ID = emp_ID;
        this.fullname = fullname;
        this.position = position;
        this.leave_from = leave_from;
        this.leave_to = leave_to;
        this.remarks = remarks;
        this.status = status;
        this.password = password;
        this.image = image;
    }
    
    // --- GETTERS ---
    // Essential for reading data from the object (e.g., to populate a TableView)

    public Integer getId() {
        return id;
    }
    
    public String getEmp_ID() {
        return emp_ID;
    }

    public String getFullname() {
        return fullname;
    }

    public String getPosition() {
        return position;
    }

    public Date getLeave_from() {
        return leave_from;
    }
    
    public Date getLeave_to() {
        return leave_to;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getStatus() {
        return status;
    }
    
    public String getPassword() {
        return password;
    }

    public String getImage() {
        return image;
    }

    // --- SETTERS ---
    // Optional, but required if you need to modify the object's data after creation

    public void setId(Integer id) {
        this.id = id;
    }
    
    public void setEmp_ID(String emp_ID) {
        this.emp_ID = emp_ID;
    }
    
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setLeave_from(Date leave_from) {
        this.leave_from = leave_from;
    }

    public void setLeave_to(Date leave_to) {
        this.leave_to = leave_to;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }

    public void setImage(String image) {
        this.image = image;
    }
}