/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.tcet.emplmanage;

import static com.tcet.emplmanage.getData.username;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.animation.AnimationTimer;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import java.io.File;
import java.sql.SQLException;
import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

/**
 * FXML Controller class
 *
 * @author shail
 */
public class DashboardController implements Initializable {

    @FXML
    private TableView<employeeData> form_tableView;

    @FXML
    private TableColumn<employeeData, String> view_col_empID;

    @FXML
    private TableColumn<employeeData, String> view_col_fullname;

    @FXML
    private TableColumn<employeeData, String> view_col_position;

    @FXML
    private TableColumn<employeeData, String> view_col_leavefrom;

    @FXML
    private TableColumn<employeeData, String> view_col_leaveto;

    @FXML
    private TableColumn<employeeData, Integer> view_col_leavedays;

    @FXML
    private TableColumn<employeeData, String> view_col_remarks;

    @FXML
    private TableColumn<employeeData, String> view_col_status;

    // Sidebar buttons
    @FXML
    private Button sidebar_home;

    @FXML
    private Button sidebar_add_employee;

    @FXML
    private Button sidebar_employee_leaves;

    // Sections/panes
    @FXML
    private Pane home_section;

    @FXML
    private ImageView form_image;

    @FXML
    private Pane emp_add_section;

    @FXML
    private Pane emp_leaves_section;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Label username;

    @FXML
    private Label home_date;

    @FXML
    private Label home_time;

    // Form fields for adding employees
    @FXML
    private TextField form_emp_ID;

    @FXML
    private TextField form_fullname;

    @FXML
    private TextField form_position;

    @FXML
    private DatePicker form_leavefrom;

    @FXML
    private DatePicker form_leaveto;

    @FXML
    private Label form_leavedays;

    @FXML
    private TextField form_remarks;

    @FXML
    private ComboBox<String> form_status;

    // Buttons
    @FXML
    private Button form_addBtn;

    @FXML
    private Button form_updateBtn;

    @FXML
    private Button form_clearBtn;

    @FXML
    private Button form_deleteBtn;

    @FXML
    private Button form_importBtn;

    // Search field
    @FXML
    private TextField search_Bar_A;

    // Employee Leaves Section Components - CORRECTED: Using Labels instead of DatePickers
    @FXML
    private TableView<employeeData> emp_tableView;

    @FXML
    private TableColumn<employeeData, String> table_col_empID;

    @FXML
    private TableColumn<employeeData, String> table_col_fullname;

    @FXML
    private TableColumn<employeeData, String> table_col_leavefrom;

    @FXML
    private TableColumn<employeeData, String> table_col_leaveto;

    @FXML
    private TableColumn<employeeData, String> table_col_status;

    @FXML
    private TextField search_Bar;

    @FXML
    private TextField employee_ID;

    @FXML
    private Label emp_fullname;      // Changed from TextField to Label

    @FXML
    private Label emp_position;      // Changed from TextField to Label

    @FXML
    private Label emp_leavefrom;     // Changed from DatePicker to Label

    @FXML
    private Label emp_leaveto;       // Changed from DatePicker to Label

    @FXML
    private Label emp_leavedays;

    @FXML
    private TextField emp_remarks;

    @FXML
    private ComboBox<String> emp_status;

    @FXML
    private Button emp_updateBtn;

    @FXML
    private Button emp_clearBtn;
    
    @FXML
    private Button token_generateBtn;

    @FXML
    private Button token_resetBtn;

    @FXML
    private Button token_viewBtn;

    @FXML
    private TextField token_display;
    
    
    @FXML
    private BarChart home_chart;
    
    @FXML
    private Label home_totalEmployees;
    
    @FXML
    private Label home_activeEmployees;
      
    @FXML
    private Label home_inactiveEmployees;

    private Connection connect;
    private Statement statement;
    private PreparedStatement prepare;
    private ResultSet result;

    private Image image;
    private String currentEmployeeId = "";

    // UPDATE METHOD
    public void addEmployeeUpdate() throws SQLException {
        String updateInfo = "UPDATE employee SET fullname = ?, position = ?, leave_from = ?, leave_to = ?, remarks = ?, status = ?, image = ? WHERE emp_ID = ?";

        connect = database.connectDb();

        try {
            Alert alert;
            if (currentEmployeeId.isEmpty()
                    || form_fullname.getText().isEmpty()
                    || form_position.getText().isEmpty()
                    || form_leavefrom.getValue() == null
                    || form_leaveto.getValue() == null
                    || form_remarks.getText().isEmpty()
                    || form_status.getSelectionModel().getSelectedItem() == null) {

                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please select an employee to update and fill all fields");
                alert.showAndWait();
            } else {
                // Convert LocalDate to java.sql.Date
                java.sql.Date sqlFromDate = java.sql.Date.valueOf(form_leavefrom.getValue());
                java.sql.Date sqlToDate = java.sql.Date.valueOf(form_leaveto.getValue());

                prepare = connect.prepareStatement(updateInfo);
                prepare.setString(1, form_fullname.getText());
                prepare.setString(2, form_position.getText());
                prepare.setDate(3, sqlFromDate);
                prepare.setDate(4, sqlToDate);
                prepare.setString(5, form_remarks.getText());
                prepare.setString(6, form_status.getSelectionModel().getSelectedItem());

                // Handle image update
                String uri = "";
                if (getData.path != null && !getData.path.isEmpty()) {
                    uri = getData.path.replace("\\", "\\\\");
                } else {
                    // Keep existing image if no new image is selected
                    String getImageSql = "SELECT image FROM employee WHERE emp_ID = ?";
                    PreparedStatement getImageStmt = connect.prepareStatement(getImageSql);
                    getImageStmt.setString(1, currentEmployeeId);
                    ResultSet imageResult = getImageStmt.executeQuery();
                    if (imageResult.next()) {
                        uri = imageResult.getString("image");
                    }
                }
                prepare.setString(7, uri);
                prepare.setString(8, currentEmployeeId);

                int affectedRows = prepare.executeUpdate();

                if (affectedRows > 0) {
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Updated!");
                    alert.showAndWait();

                    addEmployeeShowListData();
                    addEmployeeReset();
                } else {
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to update employee!");
                    alert.showAndWait();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to update employee: " + e.getMessage());
        }
    }

    // DELETE METHOD
    public void addEmployeeDelete() throws SQLException {
        String deleteInfo = "DELETE FROM employee WHERE emp_ID = ?";
        connect = database.connectDb();

        try {
            Alert alert;
            if (currentEmployeeId.isEmpty()) {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please select an employee to delete");
                alert.showAndWait();
            } else {
                // Confirmation dialog
                alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to delete employee: " + currentEmployeeId + "?");

                Optional<ButtonType> option = alert.showAndWait();

                if (option.isPresent() && option.get().equals(ButtonType.OK)) {
                    prepare = connect.prepareStatement(deleteInfo);
                    prepare.setString(1, currentEmployeeId);

                    int affectedRows = prepare.executeUpdate();

                    if (affectedRows > 0) {
                        alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Successfully Deleted!");
                        alert.showAndWait();

                        addEmployeeShowListData();
                        addEmployeeReset();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to delete employee: " + e.getMessage());
        }
    }

    // SEARCH METHOD
    public void addEmployeeSearch() throws SQLException {
        ObservableList<employeeData> searchList = FXCollections.observableArrayList();
        String searchText = search_Bar_A.getText();

        String sql = "SELECT * FROM employee WHERE emp_ID LIKE ? OR fullname LIKE ? OR position LIKE ?";

        connect = database.connectDb();

        try {
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, "%" + searchText + "%");
            prepare.setString(2, "%" + searchText + "%");
            prepare.setString(3, "%" + searchText + "%");
            result = prepare.executeQuery();

            while (result.next()) {
                java.sql.Date leaveFromDate = result.getDate("leave_from");
                java.sql.Date leaveToDate = result.getDate("leave_to");

                String leaveFrom = (leaveFromDate != null) ? leaveFromDate.toString() : "";
                String leaveTo = (leaveToDate != null) ? leaveToDate.toString() : "";
                String imagePath = result.getString("image");

                employeeData employeeD = new employeeData(
                        result.getString("emp_ID"),
                        result.getString("fullname"),
                        result.getString("position"),
                        leaveFrom,
                        leaveTo,
                        result.getString("remarks"),
                        result.getString("status"),
                        imagePath != null ? imagePath : ""
                );

                searchList.add(employeeD);
            }

            form_tableView.setItems(searchList);

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Search Error", "Failed to search employees: " + e.getMessage());
        }
    }

    // CALCULATE LEAVE DAYS
    private void calculateLeaveDays() {
        if (form_leavefrom.getValue() != null && form_leaveto.getValue() != null) {
            LocalDate fromDate = form_leavefrom.getValue();
            LocalDate toDate = form_leaveto.getValue();

            if (!fromDate.isAfter(toDate)) {
                long daysBetween = ChronoUnit.DAYS.between(fromDate, toDate) + 1;
                form_leavedays.setText(String.valueOf(daysBetween));
            } else {
                form_leavedays.setText("0");
                showAlert("Date Error", "Leave From date cannot be after Leave To date");
            }
        } else {
            form_leavedays.setText("");
        }
    }

    public void addEmployeeAdd() throws SQLException {
        if (form_leavefrom.getValue() == null || form_leaveto.getValue() == null) {
            showAlert("Error", "Please select both Leave From and Leave To dates");
            return;
        }

        java.sql.Date sqlFromDate = java.sql.Date.valueOf(form_leavefrom.getValue());
        java.sql.Date sqlToDate = java.sql.Date.valueOf(form_leaveto.getValue());

        // CORRECTED SQL - removed 'days' column and added password field
        String insertInfo = "INSERT INTO employee (emp_ID, fullname, position, leave_from, leave_to, remarks, status, password, image) VALUES(?,?,?,?,?,?,?,?,?)";
        connect = database.connectDb();

        try {
            Alert alert;
            if (form_emp_ID.getText().isEmpty()
                    || form_fullname.getText().isEmpty()
                    || form_position.getText().isEmpty()
                    || form_remarks.getText().isEmpty()
                    || form_status.getSelectionModel().getSelectedItem() == null) {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all blank fields");
                alert.showAndWait();
            } else {
                String check = "SELECT emp_ID FROM employee WHERE emp_ID = '" + form_emp_ID.getText() + "'";

                statement = connect.createStatement();
                result = statement.executeQuery(check);

                if (result.next()) {
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Employee ID: " + form_emp_ID.getText() + " already exists!");
                    alert.showAndWait();
                } else {
                    prepare = connect.prepareStatement(insertInfo);
                    prepare.setString(1, form_emp_ID.getText());
                    prepare.setString(2, form_fullname.getText());
                    prepare.setString(3, form_position.getText());
                    prepare.setDate(4, sqlFromDate);
                    prepare.setDate(5, sqlToDate);
                    prepare.setString(6, form_remarks.getText());
                    prepare.setString(7, form_status.getSelectionModel().getSelectedItem());

                    // Generate random password instead of using default
                    String generatedPassword = generatePasswordToken();
                    prepare.setString(8, generatedPassword);

                    String uri = "";
                    if (getData.path != null && !getData.path.isEmpty()) {
                        uri = getData.path.replace("\\", "\\\\");
                    }
                    prepare.setString(9, uri);

                    prepare.executeUpdate();

                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Added!\nGenerated Password: " + generatedPassword + "\nPlease save this password for login.");
                    alert.showAndWait();

                    addEmployeeShowListData();
                    addEmployeeReset();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to add employee: " + e.getMessage());
        }
    }

    public void addEmployeeReset() {
        form_emp_ID.setText("");
        form_fullname.setText("");
        form_position.setText("");
        form_leavefrom.setValue(null);
        form_leaveto.setValue(null);
        form_leavedays.setText("");
        form_remarks.setText("");
        form_image.setImage(null);
        getData.path = "";
        form_status.getSelectionModel().clearSelection();
        currentEmployeeId = "";
    }

    public void addEmployeeInsertImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Employee Image");

        File selectedFile = fileChooser.showOpenDialog(main_form.getScene().getWindow());

        if (selectedFile != null) {
            getData.path = selectedFile.getAbsolutePath();

            try {
                Image image = new Image(selectedFile.toURI().toString(), 118, 136, false, true);
                form_image.setImage(image);
            } catch (Exception e) {
                showAlert("Image Load Error", "Could not load image: " + e.getMessage());
            }
        }
    }

    private ObservableList<employeeData> addEmployeeList;

    public ObservableList<employeeData> addEmployeeListData() {
        ObservableList<employeeData> listData = FXCollections.observableArrayList();

        String sql = "SELECT id, emp_ID, fullname, position, leave_from, leave_to, remarks, status, password, image FROM employee";

        try (Connection connect = database.connectDb(); PreparedStatement prepare = connect.prepareStatement(sql); ResultSet result = prepare.executeQuery()) {

            while (result.next()) {
                java.sql.Date leaveFromDate = result.getDate("leave_from");
                java.sql.Date leaveToDate = result.getDate("leave_to");

                String leaveFrom = (leaveFromDate != null) ? leaveFromDate.toString() : "";
                String leaveTo = (leaveToDate != null) ? leaveToDate.toString() : "";
                String imagePath = result.getString("image");

                employeeData employeeD = new employeeData(
                        result.getString("emp_ID"),
                        result.getString("fullname"),
                        result.getString("position"),
                        leaveFrom,
                        leaveTo,
                        result.getString("remarks"),
                        result.getString("status"),
                        imagePath != null ? imagePath : ""
                );

                listData.add(employeeD);
            }

        } catch (Exception e) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, e);
            showAlert("Database Error", "Failed to load employee data: " + e.getMessage());
        }

        return listData;
    }

    public void addEmployeeShowListData() {
        addEmployeeList = addEmployeeListData();

        view_col_empID.setCellValueFactory(new PropertyValueFactory<>("emp_ID"));
        view_col_fullname.setCellValueFactory(new PropertyValueFactory<>("fullname"));
        view_col_position.setCellValueFactory(new PropertyValueFactory<>("position"));
        view_col_leavefrom.setCellValueFactory(new PropertyValueFactory<>("leave_from"));
        view_col_leaveto.setCellValueFactory(new PropertyValueFactory<>("leave_to"));
        view_col_remarks.setCellValueFactory(new PropertyValueFactory<>("remarks"));
        view_col_status.setCellValueFactory(new PropertyValueFactory<>("status"));

        view_col_leavedays.setCellValueFactory(cellData -> {
            employeeData employee = cellData.getValue();
            String leaveFrom = employee.getLeave_from();
            String leaveTo = employee.getLeave_to();

            if (leaveFrom != null && leaveTo != null && !leaveFrom.isEmpty() && !leaveTo.isEmpty()) {
                try {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate fromDate = LocalDate.parse(leaveFrom, formatter);
                    LocalDate toDate = LocalDate.parse(leaveTo, formatter);

                    long daysBetween = ChronoUnit.DAYS.between(fromDate, toDate) + 1;
                    return new SimpleIntegerProperty((int) daysBetween).asObject();
                } catch (Exception e) {
                    return new SimpleIntegerProperty(0).asObject();
                }
            }
            return new SimpleIntegerProperty(0).asObject();
        });

        form_tableView.setItems(addEmployeeList);
    }

    public void addEmployeeSelect() {
        employeeData employeeD = form_tableView.getSelectionModel().getSelectedItem();
        int num = form_tableView.getSelectionModel().getSelectedIndex();

        if ((num - 1) < -1) {
            return;
        }

        // Populate form fields with selected employee data
        currentEmployeeId = employeeD.getEmp_ID();
        form_emp_ID.setText(employeeD.getEmp_ID());
        form_fullname.setText(employeeD.getFullname());
        form_position.setText(employeeD.getPosition());
        form_remarks.setText(employeeD.getRemarks());
        form_status.setValue(employeeD.getStatus());

        // Set date values
        if (employeeD.getLeave_from() != null && !employeeD.getLeave_from().isEmpty()) {
            form_leavefrom.setValue(LocalDate.parse(employeeD.getLeave_from()));
        }
        if (employeeD.getLeave_to() != null && !employeeD.getLeave_to().isEmpty()) {
            form_leaveto.setValue(LocalDate.parse(employeeD.getLeave_to()));
        }

        // Calculate and set leave days
        calculateLeaveDays();

        // Load and display employee image if available
        String imagePath = employeeD.getImage();
        if (imagePath != null && !imagePath.isEmpty()) {
            try {
                String uri = "file:" + imagePath;
                image = new Image(uri, 118, 136, false, true);
                form_image.setImage(image);
                getData.path = imagePath;
            } catch (Exception e) {
                form_image.setImage(null);
                getData.path = "";
            }
        } else {
            form_image.setImage(null);
            getData.path = "";
        }
    }

    // employeeData class matching your database schema
    public static class employeeData {

        private final SimpleStringProperty emp_ID;
        private final SimpleStringProperty fullname;
        private final SimpleStringProperty position;
        private final SimpleStringProperty leave_from;
        private final SimpleStringProperty leave_to;
        private final SimpleStringProperty remarks;
        private final SimpleStringProperty status;
        private final SimpleStringProperty image;

        public employeeData(String emp_ID, String fullname, String position,
                String leave_from, String leave_to, String remarks, String status) {
            this(emp_ID, fullname, position, leave_from, leave_to, remarks, status, "");
        }

        public employeeData(String emp_ID, String fullname, String position,
                String leave_from, String leave_to, String remarks, String status, String image) {
            this.emp_ID = new SimpleStringProperty(emp_ID);
            this.fullname = new SimpleStringProperty(fullname);
            this.position = new SimpleStringProperty(position);
            this.leave_from = new SimpleStringProperty(leave_from);
            this.leave_to = new SimpleStringProperty(leave_to);
            this.remarks = new SimpleStringProperty(remarks);
            this.status = new SimpleStringProperty(status);
            this.image = new SimpleStringProperty(image);
        }

        // Getters
        public String getEmp_ID() {
            return emp_ID.get();
        }

        public String getFullname() {
            return fullname.get();
        }

        public String getPosition() {
            return position.get();
        }

        public String getLeave_from() {
            return leave_from.get();
        }

        public String getLeave_to() {
            return leave_to.get();
        }

        public String getRemarks() {
            return remarks.get();
        }

        public String getStatus() {
            return status.get();
        }

        public String getImage() {
            return image.get();
        }

        // Property getters
        public SimpleStringProperty emp_IDProperty() {
            return emp_ID;
        }

        public SimpleStringProperty fullnameProperty() {
            return fullname;
        }

        public SimpleStringProperty positionProperty() {
            return position;
        }

        public SimpleStringProperty leave_fromProperty() {
            return leave_from;
        }

        public SimpleStringProperty leave_toProperty() {
            return leave_to;
        }

        public SimpleStringProperty remarksProperty() {
            return remarks;
        }

        public SimpleStringProperty statusProperty() {
            return status;
        }

        public SimpleStringProperty imageProperty() {
            return image;
        }
    }

    public void displayUsername() {
        if (username != null) {
            username.setText(getData.username);
        }
    }

    // PASSWORD/TOKEN MANAGEMENT METHODS

    // GENERATE RANDOM PASSWORD/TOKEN
    private String generatePasswordToken() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder token = new StringBuilder();
        java.util.Random random = new java.util.Random();

        // Generate 8-character token
        for (int i = 0; i < 8; i++) {
            token.append(chars.charAt(random.nextInt(chars.length())));
        }

        return token.toString();
    }

    // GENERATE PASSWORD/TOKEN FOR SELECTED EMPLOYEE
    public void generateEmployeeToken() {
    // Add comprehensive null check
    if (employee_ID == null) {
        showAlert("System Error", "Employee ID field is not initialized. Please restart the application.");
        return;
    }
    
    String empId = employee_ID.getText();
    if (empId == null || empId.isEmpty()) {
        showAlert("Error", "Please select an employee first");
        return;
    }

    String generatedToken = generatePasswordToken();
    System.out.println("Generating token for: " + empId); // Debug

    String updatePassword = "UPDATE employee SET password = ? WHERE emp_ID = ?";
    try {
        connect = database.connectDb();
        prepare = connect.prepareStatement(updatePassword);
        prepare.setString(1, generatedToken);
        prepare.setString(2, empId);

        int affectedRows = prepare.executeUpdate();

        if (affectedRows > 0) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Token Generated");
            alert.setHeaderText(null);
            alert.setContentText("New token generated for employee: " + empId
                    + "\nToken: " + generatedToken
                    + "\nPlease save this token for login purposes.");
            alert.showAndWait();

            if (token_display != null) {
                token_display.setText(generatedToken);
            }
        } else {
            showAlert("Error", "Employee not found: " + empId);
        }
    } catch (Exception e) {
        e.printStackTrace();
        showAlert("Database Error", "Failed to generate token: " + e.getMessage());
    }
}
    
    // RESET PASSWORD/TOKEN FOR SELECTED EMPLOYEE
    public void resetEmployeeToken() {
        if (employee_ID.getText().isEmpty()) {
            showAlert("Error", "Please select an employee first");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirm Token Reset");
        confirmation.setHeaderText(null);
        confirmation.setContentText("Are you sure you want to reset the token for employee: "
                + employee_ID.getText() + "?");

        Optional<ButtonType> option = confirmation.showAndWait();

        if (option.isPresent() && option.get().equals(ButtonType.OK)) {
            String generatedToken = generatePasswordToken();

            String updatePassword = "UPDATE employee SET password = ? WHERE emp_ID = ?";
            try {
                connect = database.connectDb();
                prepare = connect.prepareStatement(updatePassword);
                prepare.setString(1, generatedToken);
                prepare.setString(2, employee_ID.getText());

                int affectedRows = prepare.executeUpdate();

                if (affectedRows > 0) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Token Reset");
                    alert.setHeaderText(null);
                    alert.setContentText("Token reset successfully for employee: " + employee_ID.getText()
                            + "\nNew Token: " + generatedToken
                            + "\nPlease save this new token.");
                    alert.showAndWait();

                    // Display the new token
                    token_display.setText(generatedToken);
                } else {
                    showAlert("Error", "Failed to reset token for employee: " + employee_ID.getText());
                }
            } catch (Exception e) {
                e.printStackTrace();
                showAlert("Database Error", "Failed to reset token: " + e.getMessage());
            }
        }
    }

    // VIEW CURRENT TOKEN (SECURE METHOD - SHOWS ONLY PARTIAL)
    public void viewEmployeeToken() {
        if (employee_ID.getText().isEmpty()) {
            showAlert("Error", "Please select an employee first");
            return;
        }

        String getPassword = "SELECT password FROM employee WHERE emp_ID = ?";
        try {
            connect = database.connectDb();
            prepare = connect.prepareStatement(getPassword);
            prepare.setString(1, employee_ID.getText());
            result = prepare.executeQuery();

            if (result.next()) {
                String currentToken = result.getString("password");
                if (currentToken != null && !currentToken.isEmpty()) {
                    // Show only first 3 characters for security
                    String maskedToken = currentToken.substring(0, 3) + "*****";

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Current Token");
                    alert.setHeaderText("Token for Employee: " + employee_ID.getText());
                    alert.setContentText("Current token: " + maskedToken
                            + "\n\nFor security reasons, only partial token is shown."
                            + "\nUse 'Generate New' or 'Reset' to get full token.");
                    alert.showAndWait();
                } else {
                    showAlert("No Token", "No token found for this employee. Please generate one first.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to retrieve token: " + e.getMessage());
        }
    }

    // EMPLOYEE LEAVES UPDATE METHOD
    public void empLeavesUpdate() {
        String updateInfo = "UPDATE employee SET fullname = ?, position = ?, leave_from = ?, leave_to = ?, remarks = ?, status = ? WHERE emp_ID = ?";

        try {
            connect = database.connectDb();
            Alert alert;
            if (employee_ID.getText().isEmpty()
                    || emp_fullname.getText().isEmpty()
                    || emp_position.getText().isEmpty()
                    || emp_leavefrom.getText().isEmpty()
                    || emp_leaveto.getText().isEmpty()
                    || emp_remarks.getText().isEmpty()
                    || emp_status.getSelectionModel().getSelectedItem() == null) {

                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please select an employee and fill all fields");
                alert.showAndWait();
            } else {
                // Parse dates from labels
                LocalDate fromDate = LocalDate.parse(emp_leavefrom.getText());
                LocalDate toDate = LocalDate.parse(emp_leaveto.getText());

                // Convert LocalDate to java.sql.Date
                java.sql.Date sqlFromDate = java.sql.Date.valueOf(fromDate);
                java.sql.Date sqlToDate = java.sql.Date.valueOf(toDate);

                prepare = connect.prepareStatement(updateInfo);
                prepare.setString(1, emp_fullname.getText());
                prepare.setString(2, emp_position.getText());
                prepare.setDate(3, sqlFromDate);
                prepare.setDate(4, sqlToDate);
                prepare.setString(5, emp_remarks.getText());
                prepare.setString(6, emp_status.getSelectionModel().getSelectedItem());
                prepare.setString(7, employee_ID.getText());

                int affectedRows = prepare.executeUpdate();

                if (affectedRows > 0) {
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Updated!");
                    alert.showAndWait();

                    empLeavesShowListData();
                    empLeavesReset();
                } else {
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to update employee!");
                    alert.showAndWait();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to update employee: " + e.getMessage());
        }
    }

    public void empLeavesSelect() {
    if (emp_tableView == null) {
        System.out.println("emp_tableView is null");
        return;
    }
    
    employeeData employeeD = emp_tableView.getSelectionModel().getSelectedItem();
    
    if (employeeD == null) {
        return;
    }

    // CRITICAL FIX: Set employee_ID before any other operations
    if (employee_ID != null) {
        employee_ID.setText(employeeD.getEmp_ID());
        System.out.println("Selected Employee ID: " + employeeD.getEmp_ID()); // Debug
    } else {
        System.out.println("ERROR: employee_ID field is null - FXML injection failed");
        showAlert("System Error", "Employee ID field not initialized. Please restart the application.");
        return;
    }
    
    // Set other fields with null checks
    if (emp_fullname != null) emp_fullname.setText(employeeD.getFullname());
    if (emp_position != null) emp_position.setText(employeeD.getPosition());
    if (emp_remarks != null) emp_remarks.setText(employeeD.getRemarks());
    if (emp_status != null) emp_status.setValue(employeeD.getStatus());

    // Set date values
    if (emp_leavefrom != null && employeeD.getLeave_from() != null && !employeeD.getLeave_from().isEmpty()) {
        emp_leavefrom.setText(employeeD.getLeave_from());
    }
    if (emp_leaveto != null && employeeD.getLeave_to() != null && !employeeD.getLeave_to().isEmpty()) {
        emp_leaveto.setText(employeeD.getLeave_to());
    }

    // Calculate leave days
    empLeavesCalculateDaysFromLabels();
    
    // Clear token display when selecting new employee
    if (token_display != null) {
        token_display.setText("");
    }
}

    // CALCULATE DAYS FROM LABEL TEXT (FOR EMPLOYEE LEAVES SECTION)
    private void empLeavesCalculateDaysFromLabels() {
        String fromText = emp_leavefrom.getText();
        String toText = emp_leaveto.getText();

        if (fromText != null && !fromText.isEmpty() && toText != null && !toText.isEmpty()) {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDate fromDate = LocalDate.parse(fromText, formatter);
                LocalDate toDate = LocalDate.parse(toText, formatter);

                if (!fromDate.isAfter(toDate)) {
                    long daysBetween = ChronoUnit.DAYS.between(fromDate, toDate) + 1;
                    emp_leavedays.setText(String.valueOf(daysBetween));
                } else {
                    emp_leavedays.setText("0");
                    showAlert("Date Error", "Leave From date cannot be after Leave To date");
                }
            } catch (Exception e) {
                emp_leavedays.setText("0");
            }
        } else {
            emp_leavedays.setText("0");
        }
    }

    // EMPLOYEE LEAVES RESET METHOD
    public void empLeavesReset() {
        employee_ID.setText("");
        emp_fullname.setText("");
        emp_position.setText("");
        emp_leavefrom.setText("");
        emp_leaveto.setText("");
        emp_leavedays.setText("0");
        emp_remarks.setText("");
        emp_status.getSelectionModel().clearSelection();
        token_display.setText("");
    }

    // EMPLOYEE LEAVES SEARCH METHOD
    public void empLeavesSearch() {
        ObservableList<employeeData> searchList = FXCollections.observableArrayList();
        String searchText = search_Bar.getText();

        String sql = "SELECT * FROM employee WHERE emp_ID LIKE ? OR fullname LIKE ? OR position LIKE ?";

        try {
            connect = database.connectDb();
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, "%" + searchText + "%");
            prepare.setString(2, "%" + searchText + "%");
            prepare.setString(3, "%" + searchText + "%");
            result = prepare.executeQuery();

            while (result.next()) {
                java.sql.Date leaveFromDate = result.getDate("leave_from");
                java.sql.Date leaveToDate = result.getDate("leave_to");

                String leaveFrom = (leaveFromDate != null) ? leaveFromDate.toString() : "";
                String leaveTo = (leaveToDate != null) ? leaveToDate.toString() : "";
                String imagePath = result.getString("image");

                employeeData employeeD = new employeeData(
                        result.getString("emp_ID"),
                        result.getString("fullname"),
                        result.getString("position"),
                        leaveFrom,
                        leaveTo,
                        result.getString("remarks"),
                        result.getString("status"),
                        imagePath != null ? imagePath : ""
                );

                searchList.add(employeeD);
            }

            emp_tableView.setItems(searchList);

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Search Error", "Failed to search employees: " + e.getMessage());
        }
    }

    // EMPLOYEE LEAVES SHOW LIST DATA
    public void empLeavesShowListData() {
        ObservableList<employeeData> empLeavesList = addEmployeeListData();

        table_col_empID.setCellValueFactory(new PropertyValueFactory<>("emp_ID"));
        table_col_fullname.setCellValueFactory(new PropertyValueFactory<>("fullname"));
        table_col_leavefrom.setCellValueFactory(new PropertyValueFactory<>("leave_from"));
        table_col_leaveto.setCellValueFactory(new PropertyValueFactory<>("leave_to"));
        table_col_status.setCellValueFactory(new PropertyValueFactory<>("status"));

        emp_tableView.setItems(empLeavesList);
    }

    // Dashboard Home Date & Time
    private AnimationTimer timer;

    public void updateDateTimeDisplay() {
        String date = getCurrentDate();
        home_date.setText(date);

        String initialTime = getCurrentTimeWithSeconds();
        home_time.setText(initialTime);

        timer = new AnimationTimer() {
            private long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (now - lastUpdate >= 1_000_000_000) {
                    String currentTime = getCurrentTimeWithSeconds();
                    home_time.setText(currentTime);
                    lastUpdate = now;
                }
            }
        };
        timer.start();
    }

    public static String getCurrentTimeWithSeconds() {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        LocalTime currentTime = LocalTime.now();
        return currentTime.format(timeFormatter);
    }

    public static String getCurrentDate() {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
        LocalDate currentDate = LocalDate.now();
        return currentDate.format(dateFormatter);
    }
    
    // HOME SECTION - EMPLOYEE COUNTS AND CHARTS
public void homeTotalEmployees() throws SQLException {
    String sql = "SELECT COUNT(id) as total_count FROM employee";
    
    connect = database.connectDb();
    int countData = 0;
    try {
        prepare = connect.prepareStatement(sql);
        result = prepare.executeQuery();

        if (result.next()) {
            countData = result.getInt("total_count");
        }
        
        if (home_totalEmployees != null) {
            home_totalEmployees.setText(String.valueOf(countData));
        } else {
            System.err.println("home_totalEmployees label is null");
        }

    } catch (Exception e) {
        e.printStackTrace();
        showAlert("Database Error", "Failed to load total employees count");
    } finally {
        closeResources();
    }
}

public void homeActiveEmployees() throws SQLException {
    String sql = "SELECT COUNT(id) as active_count FROM employee WHERE status IN ('Active', 'Leave-Approved')";
    
    connect = database.connectDb();
    int countData = 0;
    try {
        prepare = connect.prepareStatement(sql);
        result = prepare.executeQuery();

        if (result.next()) {
            countData = result.getInt("active_count");
        }
        
        if (home_activeEmployees != null) {
            home_activeEmployees.setText(String.valueOf(countData));
        } else {
            System.err.println("home_activeEmployees label is null");
        }

    } catch (Exception e) {
        e.printStackTrace();
        showAlert("Database Error", "Failed to load active employees count");
    } finally {
        closeResources();
    }
}

public void homeInactiveEmployees() throws SQLException {
    String sql = "SELECT COUNT(id) as inactive_count FROM employee WHERE status IN ('Inactive', 'Terminated', 'Leave-Rejected')";
    
    connect = database.connectDb();
    int countData = 0;
    try {
        prepare = connect.prepareStatement(sql);
        result = prepare.executeQuery();

        if (result.next()) {
            countData = result.getInt("inactive_count");
        }
        
        if (home_inactiveEmployees != null) {
            home_inactiveEmployees.setText(String.valueOf(countData));
        } else {
            System.err.println("home_inactiveEmployees label is null");
        }

    } catch (Exception e) {
        e.printStackTrace();
        showAlert("Database Error", "Failed to load inactive employees count");
    } finally {
        closeResources();
    }
}

// ENHANCED CHART METHOD WITH BETTER DATA
// IMPROVED CHART METHOD
// ENHANCED CHART METHOD WITH BETTER DATA - JAVA 11 COMPATIBLE
// YOUR ORIGINAL CHART METHOD - JUST FIXED FOR JAVA 11
public void homeChart() throws SQLException {
    if (home_chart == null) {
        System.err.println("home_chart is null - FXML injection failed");
        return;
    }
    
    home_chart.getData().clear();
    home_chart.getXAxis().setLabel("Status");
    home_chart.getYAxis().setLabel("Number of Employees");
    home_chart.setTitle("Employee Status Distribution");

    String sql = "SELECT status, COUNT(id) as count FROM employee GROUP BY status";
    
    connect = database.connectDb();

    try {
        XYChart.Series<String, Number> chartSeries = new XYChart.Series<>();
        chartSeries.setName("Employees by Status");

        prepare = connect.prepareStatement(sql);
        result = prepare.executeQuery();

        while (result.next()) {
            String status = result.getString("status");
            int count = result.getInt("count");
            
            // Format status for better display
            String displayStatus = formatStatusForChart(status);
            
            chartSeries.getData().add(new XYChart.Data<>(displayStatus, count));
        }

        home_chart.getData().add(chartSeries);

    } catch (Exception e) {
        e.printStackTrace();
        showAlert("Chart Error", "Failed to load employee chart data: " + e.getMessage());
    } finally {
        closeResources();
    }
}

private void applyStatusBasedColors() {
    // This will run after chart is rendered
    javafx.application.Platform.runLater(() -> {
        for (int i = 0; i < home_chart.getData().size(); i++) {
            XYChart.Series<String, Number> series = (XYChart.Series<String, Number>) home_chart.getData().get(i);
            for (int j = 0; j < series.getData().size(); j++) {
                XYChart.Data<String, Number> data = series.getData().get(j);
                Node node = data.getNode();
                if (node != null) {
                    String status = data.getXValue();
                    switch (status) {
                        case "Active (No Leave)": 
                            node.setStyle("-fx-bar-fill: #8C00FF;"); // Primary
                            break;
                        case "On Leave": 
                            node.setStyle("-fx-bar-fill: #413543;"); // Black
                            break;
                        case "Pending Approval": 
                            node.setStyle("-fx-bar-fill: #FF0075;"); // Red
                            break;
                        case "Leave Rejected": 
                            node.setStyle("-fx-bar-fill: #8B93FF;"); // Light Purple
                            break;
                        default: 
                            node.setStyle("-fx-bar-fill: #9E9E9E;"); // Gray
                    }
                }
            }
        }
    });
}

// ALTERNATIVE CHART - EMPLOYEE JOINING TREND (if you have join_date field)
public void homeJoiningTrendChart() throws SQLException {
    if (home_chart == null) return;
    
    home_chart.getData().clear();
    home_chart.getXAxis().setLabel("Month");
    home_chart.getYAxis().setLabel("Employees Joined");
    home_chart.setTitle("Employee Joining Trend (Last 6 Months)");

    String sql = "SELECT DATE_FORMAT(join_date, '%Y-%m') as month, COUNT(id) as count " +
                 "FROM employee WHERE join_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH) " +
                 "GROUP BY DATE_FORMAT(join_date, '%Y-%m') ORDER BY month";
    
    connect = database.connectDb();

    try {
        XYChart.Series<String, Number> chartSeries = new XYChart.Series<>();
        chartSeries.setName("Employees Joined");

        prepare = connect.prepareStatement(sql);
        result = prepare.executeQuery();

        while (result.next()) {
            String month = result.getString("month");
            int count = result.getInt("count");
            
            chartSeries.getData().add(new XYChart.Data<>(month, count));
        }

        home_chart.getData().add(chartSeries);

    } catch (Exception e) {
        // If join_date doesn't exist, fall back to status chart
        System.out.println("Join date chart failed, falling back to status chart");
        homeChart();
    } finally {
        closeResources();
    }
}

// HELPER METHODS FOR CHART FUNCTIONALITY
private String formatStatusForChart(String status) {
    if (status == null) return "Unknown";
    
    switch (status.toLowerCase()) {
        case "active": return "Active";
        case "pending": return "Pending";
        case "absent": return "Absent";
        case "leave-approved": return "On Leave";
        case "leave-rejected": return "Leave Rejected";
        case "already on leave": return "On Leave";
        case "terminated": return "Terminated";
        case "inactive": return "Inactive";
        default: return status;
    }
}
//
//private void applyChartStyles() {
//    // Apply different colors to chart bars
//    home_chart.setStyle("""
//        .chart-bar {
//            -fx-bar-fill: #2196F3;
//        }
//        .chart-bar.default-color0 {
//            -fx-bar-fill: #4CAF50; /* Green for Active */
//        }
//        .chart-bar.default-color1 {
//            -fx-bar-fill: #FF9800; /* Orange for Pending */
//        }
//        .chart-bar.default-color2 {
//            -fx-bar-fill: #F44336; /* Red for Terminated */
//        }
//        .data0.chart-bar { -fx-bar-fill: #4CAF50; }
//        .data1.chart-bar { -fx-bar-fill: #2196F3; }
//        .data2.chart-bar { -fx-bar-fill: #FF9800; }
//        .data3.chart-bar { -fx-bar-fill: #F44336; }
//        .data4.chart-bar { -fx-bar-fill: #9C27B0; }
//    """);
//}

// RESOURCE CLEANUP METHOD
private void closeResources() {
    try {
        if (result != null) result.close();
        if (prepare != null) prepare.close();
        if (statement != null) statement.close();
        if (connect != null) connect.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}

    public void switchForm(ActionEvent event) {
        if (event.getSource() == sidebar_home) {
            home_section.setVisible(true);
            emp_add_section.setVisible(false);
            emp_leaves_section.setVisible(false);
        } else if (event.getSource() == sidebar_add_employee) {
            home_section.setVisible(false);
            emp_add_section.setVisible(true);
            emp_leaves_section.setVisible(false);
            addEmployeeShowListData();
        } else if (event.getSource() == sidebar_employee_leaves) {
            home_section.setVisible(false);
            emp_add_section.setVisible(false);
            emp_leaves_section.setVisible(true);
            empLeavesShowListData(); // Load data when switching to leaves section
        }
    }

    private double x = 0;
    private double y = 0;

    public void logout() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Message");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to logout?");
        Optional<ButtonType> option = alert.showAndWait();

        try {
            if (option.isPresent() && option.get().equals(ButtonType.OK)) {
                main_form.getScene().getWindow().hide();
                Parent root = FXMLLoader.load(getClass().getResource("primary.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);

                root.setOnMousePressed((MouseEvent mouseEvent) -> {
                    x = mouseEvent.getSceneX();
                    y = mouseEvent.getSceneY();
                });

                root.setOnMouseDragged((MouseEvent mouseEvent) -> {
                    stage.setX(mouseEvent.getScreenX() - x);
                    stage.setY(mouseEvent.getScreenY() - y);
                    stage.setOpacity(.8);
                });

                root.setOnMouseReleased((MouseEvent mouseEvent) -> {
                    stage.setOpacity(1);
                });

                stage.initStyle(StageStyle.TRANSPARENT);
                stage.setScene(scene);
                stage.show();
            }
        } catch (Exception e) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, "Error during logout", e);
            showAlert("Logout Error", "Failed to logout: " + e.getMessage());
        }
    }

    public void close() {
        System.exit(0);
    }

    public void minimize() {
        Stage stage = (Stage) main_form.getScene().getWindow();
        stage.setIconified(true);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Initializes the controller class.
     */
    @Override
public void initialize(URL url, ResourceBundle rb) {
    try {
        updateDateTimeDisplay();
        displayUsername();
        
        // Initialize with proper error handling
        initializeComponents();
        initializeTokenSection();
        
        // Basic counts
         homeTotalEmployees();
         homeActiveEmployees();
         homeInactiveEmployees();

        // Chart
          homeChart();
    
    System.out.println("Home section initialized with enhanced metrics");
        
    } catch (Exception e) {
        Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, "Initialization failed", e);
        showAlert("Initialization Error", "Failed to initialize application: " + e.getMessage());
    }
}

private void initializeComponents() {
    // Initialize status ComboBox items
    if (form_status != null) {
        form_status.getItems().addAll("Active", "Pending", "Absent", "Leave-Approved", "Leave-Rejected", "Already on leave", "Terminated");
    }

    if (emp_status != null) {
        emp_status.getItems().addAll("Active", "Pending", "Absent", "Leave-Approved", "Leave-Rejected", "Already on leave", "Terminated");
    }

    // Load data for both sections
    addEmployeeShowListData();
    empLeavesShowListData();

    // Debug FXML injection
    debugFXMLInjection();
}

private void debugFXMLInjection() {
    System.out.println("FXML Injection Debug:");
    System.out.println("employee_ID: " + (employee_ID != null ? "Injected" : "NULL"));
    System.out.println("emp_tableView: " + (emp_tableView != null ? "Injected" : "NULL"));
    System.out.println("token_display: " + (token_display != null ? "Injected" : "NULL"));
}

    // INITIALIZE TOKEN SECTION
    private void initializeTokenSection() {
        // You can add any additional token-related initialization here
        System.out.println("Token management system initialized");
    }
}