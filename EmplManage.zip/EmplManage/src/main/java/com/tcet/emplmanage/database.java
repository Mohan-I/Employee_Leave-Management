/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tcet.emplmanage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Utility class for establishing a database connection.
 * @author mohan
 */
public class database {
    
    public static Connection connectDb() throws SQLException {
        try {
            Connection connect = DriverManager.getConnection(
                "jdbc:mysql://localhost/employee?serverTimezone=UTC", 
                "root", 
                ""
            );
            return connect;
        } catch(SQLException e) {
            e.printStackTrace();
            throw e; 
        }
    }
}